<?php
$name = isset($_COOKIE['name']) ? $_COOKIE['name'] : '';
$email = isset($_COOKIE['email']) ? $_COOKIE['email'] : '';
$message = isset($_COOKIE['message']) ? $_COOKIE['message'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    setcookie('name', $name, time() + (86400 * 30), '/');
    setcookie('email', $email, time() + (86400 * 30), '/');
    setcookie('message', $message, time() + (86400 * 30), '/');

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сохранение прогресса формы с помощью Cookie</title>
</head>
<body>
    <h1>Форма обратной связи</h1>
    <form method="post" action="">
        <label for="name">Имя:</label><br>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>"><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>"><br>
        
        <label for="message">Сообщение:</label><br>
        <textarea id="message" name="message"><?php echo htmlspecialchars($message); ?></textarea><br>
        
        <input type="submit" value="Отправить">
    </form>
</body>
</html>